===== AiMax Shop =====

AiMax Shop plugin adds shop features for AiMax theme.


== Changelog ==

= 1.0.0 =

    * First release!