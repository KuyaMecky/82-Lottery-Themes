<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'AiMaxPlusCustomizerSite404' ) ) {
    class AiMaxPlusCustomizerSite404 {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_action( 'customize_register', array( $this, 'register' ), 15);
        }

        function register( $wp_customize ) {

            /**
             * 404 Page
             */
            $wp_customize->add_section(
                new AiMax_Customize_Section(
                    $wp_customize,
                    'site-404-page-section',
                    array(
                        'title'    => esc_html__('404 Page', 'ai-max-plus'),
                        'priority' => aimax_customizer_panel_priority( '404' )
                    )
                )
            );

            if ( ! defined( 'AIMAX_PRO_VERSION' ) ) {
                $wp_customize->add_control(
                    new AiMax_Customize_Control_Separator(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[aimax-plus-site-404-separator]',
                        array(
                            'type'        => 'wdt-separator',
                            'section'     => 'site-404-page-section',
                            'settings'    => array(),
                            'caption'     => AIMAX_PLUS_REQ_CAPTION,
                            'description' => AIMAX_PLUS_REQ_DESC,
                        )
                    )
                );
            }

        }

    }
}

AiMaxPlusCustomizerSite404::instance();