<a id="back-to-top" href="#">
    <span id="back-to-top-hover"></span>
    <span class="back-to-top-icon"><?php echo aimax_html_output($icon); ?></span>
</a>