<div class="pre-loader loader2">
    <div class="loader-inner">
        <span class="loader-text">Loading..</span>
    </div>
</div>