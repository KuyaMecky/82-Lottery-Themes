======= AiMax Plus =====

AiMax Plus plugin adds additonal features for AiMax theme.


== Changelog ==

= 1.0.0 =

    * First release!