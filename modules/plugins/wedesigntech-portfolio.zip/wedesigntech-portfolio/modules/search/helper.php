<?php

    add_action('wp_ajax_portfolio_quick_search' , 'portfolio_quick_search');
    add_action('wp_ajax_nopriv_portfolio_quick_search','portfolio_quick_search');
    function portfolio_quick_search() {

        $search_value = wdt_sanitize_fields($_POST['wdt_sf_keyword']);
        $the_query = new WP_Query( array( 'posts_per_page' => 6, 's' => $search_value, 'post_type' => array('wdt_listings') ) );
        if( $the_query->have_posts() ) :
            while( $the_query->have_posts() ): $the_query->the_post(); ?>
                <li class="portfolio_quick_search_data_item">
                    <a href="<?php echo esc_url( get_permalink() ); ?>">
                        <?php the_post_thumbnail( 'thumbnail', array( 'class' => ' ' ) ); ?>
                        <?php the_title();?>
                    </a>
                </li>
            <?php endwhile;
            wp_reset_postdata();
        else:
            echo'<p>'. esc_html__( 'No Results Found', 'aimax') .'</p>';
        endif;

        die();
    }

?>