<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'AiMaxProAuthSocial' ) ) {
    class AiMaxProAuthSocial {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_filter( 'aimax_pro_customizer_default', array( $this, 'default' ) );
            add_action( 'aimax_general_cutomizer_options', array( $this, 'register_general' ), 30 );
        }

        function default( $option ) {

            $option['enable_social_logins']  = '0';
            $option['enable_facebook_login'] = '0';
            $option['enable_google_login']   = '0';

            return $option;
        }

        function register_general( $wp_customize ) {

            $wp_customize->add_section(
                new AiMax_Customize_Section(
                    $wp_customize,
                    'auth-social-section',
                    array(
                        'title'    => esc_html__('Social Logins Authentication', 'ai-max-pro'),
                        'panel'    => 'site-general-main-panel',
                        'priority' => 30,
                    )
                )
            );

                /**
                 * Option : Enable Social Logins
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[enable_social_logins]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control_Switch(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[enable_social_logins]', array(
                            'type'    => 'wdt-switch',
                            'section' => 'auth-social-section',
                            'label'   => esc_html__( 'Enable Social Logins', 'ai-max-pro' ),
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'ai-max-pro' ),
                                'off' => esc_attr__( 'No', 'ai-max-pro' )
                            )
                        )
                    )
                );

                /**
                 * Option : Enable Facebook Logins
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[enable_facebook_login]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control_Switch(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[enable_facebook_login]', array(
                            'type'    => 'wdt-switch',
                            'section' => 'auth-social-section',
                            'label'   => esc_html__( 'Enable Facebook Login', 'ai-max-pro' ),
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'ai-max-pro' ),
                                'off' => esc_attr__( 'No', 'ai-max-pro' )
                            ),
                            'dependency' => array( 'enable_social_logins', '!=', '' )
                        )
                    )
                );
                /**
                 * Option : Facebook App Id
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[facebook_app_id]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[facebook_app_id]', array(
                            'type'    	  => 'text',
                            'section'     => 'auth-social-section',
                            'label'       => esc_html__( 'App Id', 'ai-max-pro' ),
                            'description' => esc_html__( 'Put the facebook app id here', 'ai-max-pro' ),
                            'input_attrs' => array(
                                'value'	=> esc_html__('App Id', 'ai-max-pro'),
                            ),
                            'dependency' => array( 'enable_facebook_login|enable_social_logins', '!=|!=', '' )
                        )
                    )
                );
                /**
                 * Option : Facebook Secret
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[facebook_app_secret]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[facebook_app_secret]', array(
                            'type'    	  => 'text',
                            'section'     => 'auth-social-section',
                            'label'       => esc_html__( 'Secret Id', 'ai-max-pro' ),
                            'description' => esc_html__( 'Put the facebook app secret here', 'ai-max-pro' ),
                            'input_attrs' => array(
                                'value'	=> esc_html__('Secret Id', 'ai-max-pro'),
                            ),
                            'dependency' => array( 'enable_facebook_login|enable_social_logins', '!=|!=', '' )
                        )
                    )
                );

                /**
                 * Option : Enable Google Logins
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[enable_google_login]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control_Switch(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[enable_google_login]', array(
                            'type'    => 'wdt-switch',
                            'section' => 'auth-social-section',
                            'label'   => esc_html__( 'Enable Google Login', 'ai-max-pro' ),
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'ai-max-pro' ),
                                'off' => esc_attr__( 'No', 'ai-max-pro' )
                            ),
                            'dependency' => array( 'enable_social_logins', '!=', '' )
                        )
                    )
                );
                /**
                 * Option : Google Client Id
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[google_client_id]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[google_client_id]', array(
                            'type'    	  => 'text',
                            'section'     => 'auth-social-section',
                            'label'       => esc_html__( 'Client Id', 'ai-max-pro' ),
                            'description' => esc_html__( 'Put the google client id here', 'ai-max-pro' ),
                            'input_attrs' => array(
                                'value'	=> esc_html__('Client Id', 'ai-max-pro'),
                            ),
                            'dependency' => array( 'enable_google_login|enable_social_logins', '!=|!=', '' )
                        )
                    )
                );
                /**
                 * Option : Google Client Secret
                 */
                $wp_customize->add_setting(
                    AIMAX_CUSTOMISER_VAL . '[google_client_secret]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new AiMax_Customize_Control(
                        $wp_customize, AIMAX_CUSTOMISER_VAL . '[google_client_secret]', array(
                            'type'    	  => 'text',
                            'section'     => 'auth-social-section',
                            'label'       => esc_html__( 'Client Secret', 'ai-max-pro' ),
                            'description' => esc_html__( 'Put the google client secret here', 'ai-max-pro' ),
                            'input_attrs' => array(
                                'value'	=> esc_html__('Client Secret', 'ai-max-pro'),
                            ),
                            'dependency' => array( 'enable_google_login|enable_social_logins', '!=|!=', '' )
                        )
                    )
                );
        }

    }
}

AiMaxProAuthSocial::instance();