<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Tags -->
<div class="single-entry-tags"><?php the_tags( '', ' ', '' ); ?></div><!-- Entry Tags -->