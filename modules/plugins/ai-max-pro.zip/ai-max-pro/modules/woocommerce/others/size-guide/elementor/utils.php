<?php

/*
* Update Summary - Options Filter
*/

if( ! function_exists( 'aimax_shop_woo_single_summary_button_options_sg_render' ) ) {
	function aimax_shop_woo_single_summary_button_options_sg_render( $options ) {

		$options['sizeguide'] = esc_html__('Button Size Guide', 'ai-max-pro');
		return $options;

	}
	add_filter( 'aimax_shop_woo_single_summary_button_options', 'aimax_shop_woo_single_summary_button_options_sg_render', 10, 1 );

}

/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'aimax_shop_woo_single_summary_styles_sg_render' ) ) {
	function aimax_shop_woo_single_summary_styles_sg_render( $styles ) {

		array_push( $styles, 'swiper' );
		array_push( $styles, 'wdt-shop-size-guide' );
		return $styles;

	}
	add_filter( 'aimax_shop_woo_single_summary_styles', 'aimax_shop_woo_single_summary_styles_sg_render', 10, 1 );

}

/*
* Update Summary - Scripts Filter
*/

if( ! function_exists( 'aimax_shop_woo_single_summary_scripts_sg_render' ) ) {
	function aimax_shop_woo_single_summary_scripts_sg_render( $scripts ) {

		array_push( $scripts, 'jquery-swiper' );
		array_push( $scripts, 'wdt-shop-size-guide' );
		return $scripts;

	}
	add_filter( 'aimax_shop_woo_single_summary_scripts', 'aimax_shop_woo_single_summary_scripts_sg_render', 10, 1 );

}