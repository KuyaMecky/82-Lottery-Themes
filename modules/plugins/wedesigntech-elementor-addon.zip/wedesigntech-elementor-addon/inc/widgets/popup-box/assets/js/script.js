(function ($) {

  const wdtPopupBoxWidgetHandler = function($scope) {
      const instance = new wdtPopupBoxWidgetHandlerInit($scope);
      instance.init();
  };

  const wdtPopupBoxWidgetHandlerInit = function($scope) {

    const $self = this;
    const $settings = $scope.find('.wdt-popup-box-trigger-holder').data('settings');
    const $module_ref_id = $settings['module_ref_id'];
    const $popup_class = $settings['popup_class'];
    const $trigger_type = $settings['trigger_type'] ? $settings['trigger_type'] : 'on-click';
    const $on_load_delay = $settings['on_load_delay'] ? +$settings['on_load_delay']['size'] : 200;
    const $on_load_after = $settings['on_load_after'] ? +$settings['on_load_after']['size'] : 1;
    const $external_class = $settings['external_class'] ? $settings['external_class'] : false;
    const $external_id = $settings['external_id'] ? $settings['external_id'] : false;
    const $show_close_Button = $settings['show_close_Button'] ? $settings['show_close_Button'] : false;
    const $esc_to_exit = $settings['esc_to_exit'] ? $settings['esc_to_exit'] : false;
    const $click_to_exit = $settings['click_to_exit'] ? $settings['click_to_exit'] : false;
    const $mfp_src = $settings['mfp_src'] ? $settings['mfp_src'] : false;
    const $mfp_type = $settings['mfp_type'] ? $settings['mfp_type'] : false;
    const $mfp_button_position = ($mfp_type === 'image') ? true : false;
    const $show_animation_on_hover = $settings['animation_on_hover'] ? $settings['animation_on_hover'] : false;

    let $trigger_element = false;

    $self.init = function() {
      if($trigger_type === 'on-load') {
        $self.onLoadInit()
      } else if($trigger_type === 'on-click') {
        $trigger_element = $scope.find('.wdt-popup-box-trigger-item');
        $self.onClickInit();
      } else if($trigger_type === 'external-class') {
        $trigger_element = $($external_class);
        $self.onClickInit();
      } else if( $trigger_type === 'external-id') {
        $trigger_element = $($external_id);
        $self.onClickInit();
      }

      if( $show_animation_on_hover ) {
        $self.animationOnHover();
      }
    };

    $self.onLoadInit = function() {

      if($on_load_after === 0) {
        $.removeCookie($module_ref_id, { path: "/" });
      }
      if (!$.cookie($module_ref_id)) {
        setTimeout(function () {
          $.magnificPopup.open({
            items: {
              src: $mfp_src,
              type: $mfp_type,
            },
            removalDelay: 500,
            showCloseBtn: $show_close_Button,
            enableEscapeKey: $esc_to_exit,
            closeOnBgClick: $click_to_exit,
            mainClass: $popup_class,
            closeBtnInside: $mfp_button_position
          });


          if ($on_load_after > 0) {
            $.cookie($module_ref_id, $on_load_after, {
              expires: $on_load_after,
              path: "/",
            });
          } else {
            $.removeCookie($module_ref_id);
          }
        }, $on_load_delay);
      }

    };

    $self.onClickInit = function() {
      $trigger_element.magnificPopup({
        items: {
          src: $mfp_src,
          type: $mfp_type,
        },
        removalDelay: 500,
        showCloseBtn: $show_close_Button,
        enableEscapeKey: $esc_to_exit,
        closeOnBgClick: $click_to_exit,
        mainClass: $popup_class,
        closeBtnInside: $mfp_button_position
      });
    };

    $self.animationOnHover = function() {

      $(".wdt-media-icon-animation-holder-container").each(function() {

        const videoContainer = $(this);
        const playButton = $(this).find('.wdt-popup-box-trigger-label');

        videoContainer.mousemove(function (event) {

          const containerRect = videoContainer[0].getBoundingClientRect();
          const mouseX = event.clientX - containerRect.left;
          const mouseY = event.clientY - containerRect.top;

          const buttonWidth = playButton[0].offsetWidth;
          const buttonHeight = playButton[0].offsetHeight;
          const buttonX = mouseX - buttonWidth / 2;
          const buttonY = mouseY - buttonHeight / 2;
          const maxButtonX = containerRect.width - buttonWidth;
          const maxButtonY = containerRect.height - buttonHeight;

          playButton.css( "left", Math.min(Math.max(buttonX, 0), maxButtonX) + "px" );
          playButton.css( "top", Math.min(Math.max(buttonY, 0), maxButtonY) + "px" );

        });

        videoContainer.mouseleave(function () {
          setTimeout(function () {
            playButton.css({ 
                "left" : "50%", 
                "top" : "50%", 
                "transform" : "translate(-50%, -50%) scale(1)", 
                "transition" : "all 0.3s ease-out" 
              });
          }, 50);
        });

        videoContainer.mouseover(function () {
          playButton.css({ 
              "transition" : "transform ease-out 0.3s", 
              "transform" : "scale(1.2)" 
            });
        });

      });

    };

  };

  $(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/wdt-popup-box.default', wdtPopupBoxWidgetHandler);
  });

})(jQuery);
